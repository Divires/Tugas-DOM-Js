// script.js
function changeImage() {
    const imageElement = document.getElementById('myImage');
    const currentSrc = imageElement.src;

    // Ganti gambar berdasarkan kondisi saat ini
    if (currentSrc.endsWith('all.jpg')) {
        imageElement.src = 'sdr2.jpg';
    } else {
        imageElement.src = 'all.jpg';
    }
}
